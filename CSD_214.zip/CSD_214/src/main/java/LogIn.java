public class LogIn {
    private int user_id;

    private String user_name;

    private String user_email;

    private int user_password;

    public void setuser_id(int user_id) {
        this.user_id = user_id;
    }

    public void setuser_name(int user_name) {
        this.user_name = user_name;

    }
    public void setuser_email(int user_email) {
        this.user_email = user_email;
}
    public void setuser_password(int user_password) {
        this.user_password = user_password;
    }

    public LogIn(int user_id, String user_name, String user_email, int user_password) {
        this.user_id = user_id;
        this.user_name = user_name;
        this.user_email = user_email;
        this.user_password = user_password;

    }

    public int getUser_id() { return user_id; }
public String getUser_name() { return user_name;}
    public String getUser_email() { return user_email;}

    public int getUser_password() { return user_password;}

}


