public class Inventory_Management {

        private int item_id;

        private String item_name;

        private String item_quantity;

        private int item_price;

        public void setItem_id(int Item_id) {
            this.item_id = item_id;
        }

        public void setItem_name (int Item_name) {
            this.item_name = item_name;

        }
        public void setItem_quantity (int Item_quantity) {
            this.item_quantity = item_quantity;
        }
        public void setItem_price (int getItem_price) {
            this.item_price = item_price;
        }

        public Inventory_Management(int item_id, String item_name, String item_quantity, int item_price) {
            this.item_id = item_id;
            this.item_name = item_name;
            this.item_quantity = item_quantity;
            this.item_price = item_price;

        }

        public int getitem_id() { return item_id; }
        public String getitem_name() { return item_name;}
        public String getitem_quantity() { return item_quantity;}

        public int getitem_price() { return item_price;}

    }
}
